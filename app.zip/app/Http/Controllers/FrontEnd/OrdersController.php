<?php

namespace App\Http\Controllers\FrontEnd;

use App\Reply;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Setting;
use App\User;
use Auth;
use Hash;
use App\Order;
use Carbon;
use Image;

class OrdersController extends Controller {

    function __construct() {
        $this->middleware('auth');
    }

    //index
    function index() {
 $data['setting'] = Setting::find(1);
        return view('order.home',$data);
    }

    //new orders
    function newOrderPage() {
$data['setting'] = Setting::find(1);
        return view('order.new',$data);
    }

    //  order 
    public function order(Request $request) {


        $this->validate($request, [
            'title' => 'required',
            'message' => 'required',
        ]);
        $image = $request->file('imgPath');

        $input['imagename'] = time() . '.' . $image->getClientOriginalExtension();

        $destinationPath = base_path() . '/img/';

        $img = Image::make($image->getRealPath(), array(
                    'width' => 300,
                    'height' => 300,
                        //  'grayscale' => false
        ));
        // $img->crop(new Point(0, 0), new Box(45, 45));
        $img->save($destinationPath . '/' . $input['imagename']);

        $destinationPath = base_path() . '/img/thumbnail';

        $image->move($destinationPath, $input['imagename']);

        $order = new Order();
        $order->user_id = Auth::user()->id;
        $order->work_id = 0;
        $order->branch = $request->branch;
        $order->title = $request->title;
        $order->message = $request->message;
        $order->img = $input['imagename'];
 $order->time =Carbon\Carbon::now();
        $order->save();
        $request->session()->flash('alert-success', 'تم بنجاح');
        return redirect()->back();
    }

    ////orders
    public function orders() {


$data['setting'] = Setting::find(1);
        $data['orders'] = Order::where('user_id', Auth::user()->id)->withCount('replies')->orderby('id', 'desc')->paginate(10);

        return view('order.orders', $data);
    }

    ////replies
    public function replies($id) {
$data['setting'] = Setting::find(1);
        $data['order'] = Order::findorfail($id);
        $data['id'] = $id;
        $data['replies'] = Reply::where('order_id', $id)->orderby('id','desc')->get();

        return view('order.reply', $data);
    }

    function reply(Request $request) {
        if (Auth::check()) {
            $this->validate($request, [
                'reply' => 'required',
            ]);
if($request->imgPath!=null){
  $image = $request->file('imgPath');
        $input['imagename'] = time() . '.' . $image->getClientOriginalExtension();

        $destinationPath = base_path() . '/img/';

        $img = Image::make($image->getRealPath(), array(
                    'width' => 300,
                    'height' => 300,
                        //  'grayscale' => false
        ));
        // $img->crop(new Point(0, 0), new Box(45, 45));
        $img->save($destinationPath . '/' . $input['imagename']);

        $destinationPath = base_path() . '/img/thumbnail';

        $image->move($destinationPath, $input['imagename']);
}
            $reply = new Reply();
            $reply->massege = $request->reply;
            $reply->user_id = Auth::user()->id;
            $reply->order_id = $request->id;
if($request->imgPath!=null){
  $reply->img = $input['imagename'];
}
            $reply->time = $mytime = Carbon\Carbon::now();
            $reply->save();
            $request->session()->flash('alert-success', 'تم بنجاح');
            return redirect()->back();
        }
    }

}
