@extends('front.app')
@section('title', '| فرع  '.$title)
@section('content') 

<div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container slide-overlay" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">

    <!-- START REVOLUTION SLIDER 5.3.0.2 auto mode -->
    <div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">
        <div class="slotholder"></div>

        <ul><!-- SLIDE  -->

            <!-- SLIDE 1 -->
            <li data-index="rs-3050" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                <!-- <div class="overlay">
                </div> -->
                <!-- MAIN IMAGE -->
                <img src="{{asset('img/thumbnail/'. $b_setting->img1)}}"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->
                <!-- LAYER NR. 12 -->
      

                <!-- LAYER NR. 12 -->
                <div class="tp-caption sub-title position" 
                     id="slide-3050-layer-3" 
                     data-x="['left','left','left','left']" data-hoffset="['35','25','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-122','-122','-122','-122']"
                     data-fontsize="['16',16','16','14']" 
                     data-fontweight="['600','600','600','600']"
                     data-width="['660','660','660','300']"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: nowrap;text-transform:left;">
                </div>

                <!-- LAYER NR. 13 -->
                <div class="tp-caption sub-title" 
                     id="slide-3050-layer-4" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['12','12','-20,'-20']"
                     data-fontsize="['18',18','18','16']" 
                     data-lineheight="['30','30','22','16']"
                     data-fontweight="['400','400','400','400']"
                     data-width="['800',800','800','450']"
                     data-height="none"
                     data-whitespace="['nowrap',normal','normal','normal']" 

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: normal;">
                </div>

             
            </li>

            <!-- SLIDE 2 -->
            <li data-index="rs-3051" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                <!-- <div class="overlay">
                </div> -->
                <!-- MAIN IMAGE -->
                <img src="{{asset('img/thumbnail/'. $b_setting->img2)}}"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->
                <!-- LAYER NR. 12 -->
                <div class="tp-caption title-slide" 
                     id="slide-3051-layer-1" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-82','-82','-82','-82']" 
                     data-fontsize="['60','60','50','33']"
                     data-lineheight="['70','70','50','35']"
                     data-fontweight="['700','700','700','700']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on"                             

                     data-frames='[{"delay":100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[10,10,10,10]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 16; white-space: nowrap;">
                </div>

                <!-- LAYER NR. 12 -->
                <div class="tp-caption sub-title position" 
                     id="slide-3051-layer-3" 
                     data-x="['left','left','left','left']" data-hoffset="['35','25','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-122','-122','-122','-122']"
                     data-fontsize="['16',16','16','14']" 
                     data-fontweight="['600','600','600','600']"
                     data-width="['660','660','660','300']"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: nowrap;text-transform:left;">
                </div>

                <!-- LAYER NR. 13 -->
                <div class="tp-caption sub-title" 
                     id="slide-3051-layer-4" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['12','12','-20,'-20']"
                     data-fontsize="['18',18','18','16']" 
                     data-lineheight="['30','30','22','16']"
                     data-fontweight="['400','400','400','400']"
                     data-width="['800',800','800','450']"
                     data-height="none"
                     data-whitespace="['nowrap',normal','normal','normal']" 

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: normal;"><br>
                </div>

           
            </li>

        </ul>
    </div>
</div>
<section class="flat-row bg-section">
    <div class="container">   
        <div class="row">
            <div class="col-md-12">  
                <div class="title-section style3 text-center">
                    <h1 class="title">خدمات فرع  {{$title}}</h1>
                </div>          
            </div>
        </div>
        <ul id="data-effect" class="data-effect wrap-iconbox clearfix">
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class="icon_currency"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$b_setting->service1}}</h5>  
                            <p>{{$b_setting->service1_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class="icon_search-2"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$b_setting->service2}}</h5>  
                            <p>{{$b_setting->service2_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>   
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class=" icon_headphones"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$b_setting->service3}}</h5>  
                            <p>{{$b_setting->service3_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>
            </ul>
    </div> 
</section>

<section class="flat-row v4 section-testimonials2">
    <div class="container">
        <div class="row">
            <div class="col-md-6 reponsive-onehalf">
                <div class="title-section style2 left">
                    <h1 class="title">أعمالنا فرع {{$title}}</h1>
                    <div class="sub-title">

                    </div>
                </div>
            </div>
            <div class="col-md-6 reponsive-onehalf">
                <div class="btn-showall float-right">
                    <a href="{{route('front.works.branch',$id)}}" class="flat-button">جميع اعمالنا</a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrap-imagebox flat-carousel" data-item="5" data-nav="false" data-dots="false" data-auto="false"> 
          @foreach($works as $work)
            <div class="imagebox">
                <div class="imagebox-image"> 
                    <a href=""><img src="{{asset('img/'.$work->img)}}" style="width:270px;height: 210px" alt="image"></a> 
                </div> 
                <div class="imagebox-content">
                 <h5 class="imagebox-title"><a href="{{route('front.work.details',$work->id)}}" widht="">{{$work->title}}</a></h5>
                  <p class="imagebox-category">
                  @if($work->branch==1)
                  الرياض
                  @elseif($work->branch==2))
                  الصين
                  @else
                  تركيا
                  @endif
                  
                  </p>
                </div>
            </div>
          @endforeach
    </div>
</section> 

<section class="flat-row section-iconbox padding2 bg-section ">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="title-section style3 left">
                    <h1 class="title">عروضنا</h1>
                </div>
            </div>
            <div class="col-md-7">
                <div class="title-section padding-left50">
                    <div class="sub-title style3">
                        أحدث العروض في شركة
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $i=1;?>
            @foreach ($offers as $offer)
          
            <img id="myImg{{$i}}" src="{{asset('img/'.$offer->img)}}" alt="{{$offer->title}}" width="300" height="200">
<?php $i++;?>
            @endforeach
       

            <!-- The Modal -->
            <div id="myModal" class="modal">
                <span class="close">&times;</span>
                <img class="modal-content" id="img01">
                <div id="caption"></div>
            </div>

            <script>
                // Get the modal
                var modal = document.getElementById('myModal');

                // Get the image and insert it inside the modal - use its "alt" text as a caption
                  <?php $i=1;?>
               @foreach ($offers as $offer)
                var img{{$i}} = document.getElementById('myImg{{$i}}');
                var modalImg = document.getElementById("img01");
                var captionText = document.getElementById("caption");
                
                img{{$i}}.onclick = function () {
                    modal.style.display = "block";
                    modalImg.src = this.src;
                    captionText.innerHTML = this.alt;
                }
              <?php $i++;?>
            @endforeach 

                // Get the <span> element that closes the modal
                var span = document.getElementsByClassName("close")[0];

                // When the user clicks on <span> (x), close the modal
                span.onclick = function () {
                    modal.style.display = "none";
                }
            </script>       
        </div>  
    </div>
</section>

<section class="flat-row section-iconbox section-testimonials2">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="title-section style3 left">
                    <h1 class="title">عنوان الفرع</h1>
                </div>
            </div>
            <div class="col-md-7">
                <div class="title-section padding-left50">
                    <div class="sub-title style3">
                        {{$b_setting->address1}}
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="flat-maps box-shadow3 margin-bottom-73">
                    <div class="maps2" id='map2' style="width: 100%; height: 520px; "></div> 
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('js')
 <!--  <script src="{{asset('style/web/javascript/gmap3.min.js')}}"></script>-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBtwK1Hd3iMGyF6ffJSRK7I_STNEXxPdcQ&region=GB"></script>
<script>

var mapOptions = {
	    center: { lat:  {{$b_setting->Latitude}} , lng:  {{$b_setting->longitude}} },
	    zoom:16
	};
	var map = new google.maps.Map(document.getElementById('map2'), mapOptions)
var marker = new google.maps.Marker({
    position:new google.maps.LatLng(<?= $b_setting->Latitude?>, <?= $b_setting->longitude?>) ,
    map: map,
    title: 'عنواتنا!'
  });
map.setCenter(marker.position);
myMarker.setMap(map);
</script>
@endsection
