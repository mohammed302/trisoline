@extends('front.app')

@section('content')
 <div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container slide-overlay" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">

    <!-- START REVOLUTION SLIDER 5.3.0.2 auto mode -->
    <div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">
        <div class="slotholder"></div>

        <ul><!-- SLIDE  -->

            <!-- SLIDE 1 -->
            <li data-index="rs-3050" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                <!-- <div class="overlay">
                </div> -->
                <!-- MAIN IMAGE -->
                <img src="{{asset('img/thumbnail/'. $home_setting->img1)}}"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->
                <!-- LAYER NR. 12 -->
                <div class="tp-caption title-slide" 
                     id="slide-3050-layer-1" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-82','-82','-82','-82']" 
                     data-fontsize="['60','60','50','33']"
                     data-lineheight="['70','70','50','35']"
                     data-fontweight="['700','700','700','700']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on"                             

                     data-frames='[{"delay":100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[10,10,10,10]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 16;    text-shadow: -3px -2px #f2c21a; overflow: inherit;   
                     font: 77px/85px aaa !important; white-space: nowrap;">{{$setting->name}}
                </div>

                <!-- LAYER NR. 12 -->
                <div class="tp-caption sub-title position" 
                     id="slide-3050-layer-3" 
                     data-x="['left','left','left','left']" data-hoffset="['35','25','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-122','-122','-122','-122']"
                     data-fontsize="['16',16','16','14']" 
                     data-fontweight="['600','600','600','600']"
                     data-width="['660','660','660','300']"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: nowrap;text-transform:left;">
                </div>

                <!-- LAYER NR. 13 -->
                <div class="tp-caption sub-title" 
                     id="slide-3050-layer-4" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['12','12','-20,'-20']"
                     data-fontsize="['18',18','18','16']" 
                     data-lineheight="['30','30','22','16']"
                     data-fontweight="['400','400','400','400']"
                     data-width="['800',800','800','450']"
                     data-height="none"
                     data-whitespace="['nowrap',normal','normal','normal']" 

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: normal;">
                </div>

                <a href="{{route('front.about_us')}}" target="_self" class="tp-caption flat-button text-center"         

                   data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'

                   data-x="['center','center','center','center']" data-hoffset="['-502','-400','-240','-70']" 
                   data-y="['middle','middle','middle','middle']" data-voffset="['106','106','80','50']" 
                   data-fontweight="['700','700','700','700']"
                   data-width="['auto']"
                   data-height="['auto']"
                   style="z-index: 3;"> من نحن
                </a><!-- END LAYER LINK -->

                <a href="{{route('front.contact')}}" target="_self" class="tp-caption flat-button style2 text-center"         

                   data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeInOut"},{"delay":"wait","speed":1000,"to":"y:[100%];","mask":"x:inherit;y:inherit;s:inherit;e:inherit;","ease":"Power2.easeInOut"}]'

                   data-x="['center','center','center','center']" data-hoffset="['-318','-200','-30','-70']" 
                   data-y="['middle','middle','middle','middle']" data-voffset="['106','106','80','110']" 
                   data-fontweight="['700','700','700','700']"
                   data-width="['auto']"
                   data-height="['auto']"
                   style="z-index: 3;"> اتصل بنا
                </a><!-- END LAYER LINK -->
            </li>

            <!-- SLIDE 2 -->
            <li data-index="rs-3051" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                <!-- <div class="overlay">
                </div> -->
                <!-- MAIN IMAGE -->
                <img src="{{asset('img/thumbnail/'. $home_setting->img2)}}"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->
                <!-- LAYER NR. 12 -->
                <div class="tp-caption title-slide" 
                     id="slide-3051-layer-1" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-82','-82','-82','-82']" 
                     data-fontsize="['60','60','50','33']"
                     data-lineheight="['70','70','50','35']"
                     data-fontweight="['700','700','700','700']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on"                             

                     data-frames='[{"delay":100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[10,10,10,10]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 16; white-space: nowrap;    text-shadow: 4px 4px #f2c21a">
                </div>

                <!-- LAYER NR. 12 -->
                <div class="tp-caption sub-title position" 
                     id="slide-3051-layer-3" 
                     data-x="['left','left','left','left']" data-hoffset="['35','25','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-122','-122','-122','-122']"
                     data-fontsize="['16',16','16','14']" 
                     data-fontweight="['600','600','600','600']"
                     data-width="['660','660','660','300']"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: nowrap;text-transform:left;">
                </div>

                <!-- LAYER NR. 13 -->
                <div class="tp-caption sub-title" 
                     id="slide-3051-layer-4" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['12','12','-20,'-20']"
                     data-fontsize="['18',18','18','16']" 
                     data-lineheight="['30','30','22','16']"
                     data-fontweight="['400','400','400','400']"
                     data-width="['800',800','800','450']"
                     data-height="none"
                     data-whitespace="['nowrap',normal','normal','normal']" 

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: normal;"><br>
                </div>

         
            </li>

            <!-- SLIDE 3 -->
            <li data-index="rs-3051" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                <!-- <div class="overlay">
                </div> -->
                <!-- MAIN IMAGE -->
                <img src="{{asset('img/thumbnail/'. $home_setting->img3)}}"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                <!-- LAYERS -->
                <!-- LAYER NR. 12 -->
                <div class="tp-caption title-slide" 
                     id="slide-3051-layer-1" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-82','-82','-82','-82']" 
                     data-fontsize="['60','60','50','33']"
                     data-lineheight="['70','70','50','35']"
                     data-fontweight="['700','700','700','700']"
                     data-width="none"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on"                             

                     data-frames='[{"delay":100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[10,10,10,10]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 16; white-space: nowrap;     text-shadow: rgb(255, 60, 60) -3px -2px;">
                </div>

                <!-- LAYER NR. 12 -->
                <div class="tp-caption sub-title position" 
                     id="slide-3051-layer-3" 
                     data-x="['left','left','left','left']" data-hoffset="['35','25','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['-122','-122','-122','-122']"
                     data-fontsize="['16',16','16','14']" 
                     data-fontweight="['600','600','600','600']"
                     data-width="['660','660','660','300']"
                     data-height="none"
                     data-whitespace="nowrap"

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: nowrap;text-transform:left;">
                </div>

                <!-- LAYER NR. 13 -->
                <div class="tp-caption sub-title" 
                     id="slide-3051-layer-4" 
                     data-x="['left','left','left','left']" data-hoffset="['35','20','50','50']" 
                     data-y="['middle','middle','middle','middle']" data-voffset="['12','12','-20,'-20']"
                     data-fontsize="['18',18','18','16']" 
                     data-lineheight="['30','30','22','16']"
                     data-fontweight="['400','400','400','400']"
                     data-width="['800',800','800','450']"
                     data-height="none"
                     data-whitespace="['nowrap',normal','normal','normal']" 

                     data-type="text" 
                     data-responsive_offset="on" 

                     data-frames='[{"delay":1100,"speed":3000,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'

                     data-textAlign="['left','left','left','left']"
                     data-paddingtop="[0,0,0,0]"
                     data-paddingright="[0,0,0,0]"
                     data-paddingbottom="[0,0,0,0]"
                     data-paddingleft="[0,0,0,0]"

                     style="z-index: 17; white-space: normal;"><br>
                </div>

           
            </li>
        </ul>
    </div>
</div>

    <section class="flat-row section-image">
        <div class="container">
            <div class="row">
                <div class="col-md-12">  
                    <div class="title-section style3 text-center padding-lr140">
                        <h1 class="title">من نحن</h1>
                        <div class="sub-title style2">
                            {{$home_setting->about}}
                        </div>
                    </div>         
                </div><!-- /.col-md-12 -->  
            </div>
       </div> 
    </section> 
     <section class="flat-row bg-section">
        <div class="container">   
         <div class="row">
                <div class="col-md-12">  
                    <div class="title-section style3 text-center">
                        <h1 class="title">خدماتنا</h1>
                    </div>          
                </div>
            </div>
            <ul id="data-effect" class="data-effect wrap-iconbox clearfix">
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class="icon_currency"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$home_setting->service1}}</h5>  
                            <p>{{$home_setting->service1_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class="icon_search-2"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$home_setting->service2}}</h5>  
                            <p>{{$home_setting->service2_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>   
                <li>
                    <div class="iconbox effect bg-image text-center">
                        <div class="box-header">
                            <div class="box-icon">
                                <i class=" icon_headphones"></i>
                            </div>
                        </div>
                        <div class="box-contentt">
                            <h5  class="box-title">{{$home_setting->service3}}</h5>  
                            <p>{{$home_setting->service3_desc}}</p> 
                        </div>
                        <div class="effecthover">
                            <img src="{{asset('style/web/images/imagebox/1.jpg')}}" alt="image">
                        </div>
                    </div>
                </li>
            </ul>
        </div> 
    </section>

    <section class="flat-row v4 section-testimonials2">
        <div class="container">
            <div class="row">
                <div class="col-md-6 reponsive-onehalf">
                    <div class="title-section style2 left">
                        <h1 class="title">أعمالنا</h1>
                       
                    </div>
                </div>
                <div class="col-md-6 reponsive-onehalf">
                    <div class="btn-showall float-right">
                        <a href="{{route('front.works')}}" class="flat-button">جميع اعمالنا</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="wrap-imagebox flat-carousel" data-item="5" data-nav="false" data-dots="false" data-auto="false"> 
          @foreach($works as $work)
            <div class="imagebox">
                <div class="imagebox-image"> 
                    <a href=""><img src="{{asset('img/'.$work->img)}}" style="width:270px;height: 210px" alt="image"></a> 
                </div> 
                <div class="imagebox-content">
                 <h5 class="imagebox-title"><a href="{{route('front.work.details',$work->id)}}" widht="">{{$work->title}}</a></h5>
                  <p class="imagebox-category">
                  @if($work->branch==1)
                  الرياض
                  @elseif($work->branch==2)
                  الصين
                  @else
                  تركيا
                  @endif
                  
                  </p>
                </div>
            </div>
          @endforeach
          
        </div>
    </section> 

    

    

    

    <section class="flat-row bg-section">
        <div class="container">
          <div class="row">
                <div class="col-md-12">  
                    <div class="title-section style3 text-center">
                        <h1 class="title">اتصل بنا</h1>
                    </div>          
                </div>
            </div>
                 
            
                <div class="row">
                    <div class="col-lg-4">
                        <div class="info-box text-center">
                            <h3>الرياض</h3>
                            <ul>
                                <li>{{$home_setting->address1}}</li>
                                <li>البريد الإلكتروني: {{$home_setting->email1}}</li>
                                <li>الهاتف: {{$home_setting->tel1}}</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="info-box text-center">
                            <h3> الصين</h3>
                            <ul>
                                <li>{{$home_setting->address2}}</li>
                                <li>البريد الإلكتروني: {{$home_setting->email2}}</li>
                                <li>الهاتف: {{$home_setting->tel2}}</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="info-box text-center">
                            <h3> تركيا</h3>
                            <ul>
                                <li>{{$home_setting->address3}}</li>
                                <li>البريد الإلكتروني: {{$home_setting->email3}}</li>
                                <li>الهاتف: {{$home_setting->tel3}}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            
        </div>
          
    </section>

 
@endsection
