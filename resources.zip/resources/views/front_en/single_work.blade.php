@extends('front_en.app')
@section('title', '| '.$work->title_e)
@section('content')
    <!-- Page title -->
    <div class="page-title parallax parallax1">
        <div class="section-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-title-heading">
                        <h1 class="title">{{$work->title_e}} </h1>
                    </div><!-- /.page-title-captions -->
                    <div class="breadcrumbs">
                        <ul>
                            <li class="home"><i class="fa fa-home"></i><a href="{{route('fronten.index')}}">Home </a></li>
                            <li>Work details  </li>
                        </ul>
                    </div><!-- /.breadcrumbs -->
                </div><!-- /.col-md-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- /.page-title -->

    <!-- Blog posts -->
    <section class="flat-row project-single">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-post">
                        <div class="single-text1">
                         <?=$work->description_e?>
                        </div>

                    </div>
                </div><!-- /.col-md-6 -->
                <div class="col-lg-6">
                    <div class="featured-single">

                        <img src="{{asset('img/thumbnail/'.$work->img)}}" alt="image" class="img1">

                    </div>
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>


    <section class="flat-row page-contact">

        <div class="container">
            <div class="wrap-formcontact">
                <div class="row">
                    <h2>Order</h2>
                    <div class="col-lg-7">
                        <div class="margin-left_12">
                            <form id="order" class="contactform style4 clearfix" method="post" action="" novalidate="novalidate">
                                {{ csrf_field() }}
                                <input type="hidden" name="work_id" value="{{$work->id}}">
                                <input type="hidden" name="branch" value="{{$work->branch}}">
                                <span class="flat-input"><textarea name="message" class="message" placeholder="Messages" required=""></textarea></span>
                                @if(Auth::check())
                                <span class="flat-input"><button name="submit" type="submit" class="flat-button"  title="Submit now"> Order</button></span>
                                    @else
                                    <span class="flat-input"><button  id="nologin" type="button" class="flat-button"  > Order</button></span>
                                @endif
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



@endsection
@section('js')
    <script>
        $( "#nologin" ).click(function() {
            toastr.error('Login');
        });

        $('#order').validate({
            rules: {
                message: {
                    required: true
                },

            },
            messages: {


            },
            submitHandler: function (form) {
                var _token = $("input[name='_token']").val();
                var msg = $(".message").val()
                var id = $("input[name='work_id']").val();
                var br = $("input[name='branch']").val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $("input[name='_token']").attr('content')
                    }
                });
                $.ajax({
                    url: "{{route('front.work.order')}}",
                    type: 'POST',
                    data: {_token: _token, message: msg, work_id: id,branch: br},
                    success: function (data) {
                        toastr.success('Done');
                        var msg = $(".message").val("");
                    },
                    error: function (data)
                    {
                        console.log(data);
//  toastr.options.timeOut = 1500; // 1.5s
                        toastr.error('Error');

                    }
                });

            }
        });
    </script>
@endsection
