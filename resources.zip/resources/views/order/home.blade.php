@extends('order.app')

@section('content')


 <!-- Start Header -->
        <div class="main">
          <div class="overlay">
            <div class="container table">
              <div class="row-table">
               <div class="intro text-center">
<br>

                <a href="{{route('front.index')}}" rel="home " style="float: right;">
                                    <img src="{{ asset('img/'.$setting->logo)}}" alt="image">
                                </a>
                   
                <h1>قسم  <span style="color:red">  الطلبات</span></h1>
                
                <div class="button-m"> 
                    <a  href="{{route('orders.new')}}" class="btn btn-default" role="button"> طلب جديد </a>
                    <a  href="{{route('orders.myoreders')}}" class="btn btn-default" role="button">الطلبات </a>
                </div>
               </div>
             </div>
            </div>
        </div>
      </div>
        <!-- End Header -->
@endsection
