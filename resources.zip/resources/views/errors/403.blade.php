@extends('web.app')
@section('title', 'زاول ')
@section('style', '
    padding-top: 90px;
')
@section('content')


<!-- Content
================================================== -->
<div class="container">
	<div class="page sixteen columns">
		<div class="page-content">
                    <h3 class="page-title" style="
    text-align: center;
">الصفحة المطلوبة غير موجودة!
404
للأسف لم يتم العثور على الصفحة التي طلبتها. قد يكون الرابط خاطئ أو الصفحة حذفت. </h3>
			
		</div>
	</div>

</div>
@endsection
