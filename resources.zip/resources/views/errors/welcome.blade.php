@extends('layouts.app')

@section('content')
404
@endsection